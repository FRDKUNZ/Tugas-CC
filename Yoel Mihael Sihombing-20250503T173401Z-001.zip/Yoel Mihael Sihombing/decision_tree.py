import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn import preprocessing
import matplotlib.pyplot as plt
from sklearn import tree
# 1. Load Data
df = pd.read_csv('D:\yoel\kelulusan.csv')

# 2. Convert Label (Encoding 'Lulus' to numeric values)
le = preprocessing.LabelEncoder()
df['Lulus'] = le.fit_transform(df['Lulus'])  # Converts 'Ya' to 1, 'Tidak' to 0

# 3. Select Features and Label
X = df[['Kehadiran', 'Nilai_Tugas', 'Nilai_UTS', 'Nilai_UAS']]  # Features (input variables)
y = df['Lulus']  # Label (target variable)

# 4. Split the Data into Training and Testing Sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 5. Train the Decision Tree Model
clf = DecisionTreeClassifier()
clf.fit(X_train, y_train)

# 6. Evaluate the Model (Accuracy)
accuracy = clf.score(X_test, y_test)
print("Accuracy of the Decision Tree Classifier: {:.2f}%".format(accuracy * 100))

# 7. Visualize the Decision Tree
plt.figure(figsize=(12, 8))
tree.plot_tree(clf, feature_names=['Kehadiran', 'Nilai_Tugas', 'Nilai_UTS', 'Nilai_UAS'], 
               class_names=le.classes_, filled=True, fontsize=10)
plt.show()

# Optionally: Save the Model
# import joblib
# joblib.dump(clf, 'decision_tree_model.pkl')