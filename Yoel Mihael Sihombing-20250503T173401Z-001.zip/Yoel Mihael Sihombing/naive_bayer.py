import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn import preprocessing
from sklearn.metrics import accuracy_score, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns

# 1. Load Data
df = pd.read_csv('D:\yoel\kelulusan.csv')

# 2. Convert Label (Encoding 'Lulus' to numeric values)
le = preprocessing.LabelEncoder()
df['Lulus'] = le.fit_transform(df['Lulus'])  # Converts 'Ya' to 1, 'Tidak' to 0

# 3. Select Features and Label
X = df[['Kehadiran', 'Nilai_Tugas', 'Nilai_UTS', 'Nilai_UAS']]  # Features (input variables)
y = df['Lulus']  # Label (target variable)

# 4. Split the Data into Training and Testing Sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 5. Train the Naive Bayes Model
nb = GaussianNB()
nb.fit(X_train, y_train)

# 6. Predict and Evaluate the Model
y_pred = nb.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
print("Accuracy of the Naive Bayes Classifier: {:.2f}%".format(accuracy * 100))

# 7. Confusion Matrix
conf_matrix = confusion_matrix(y_test, y_pred)
plt.figure(figsize=(6, 4))
sns.heatmap(conf_matrix, annot=True, fmt="d", cmap="Blues", xticklabels=le.classes_, yticklabels=le.classes_)
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.title('Confusion Matrix')
plt.show()

# 8. Predicted Probabilities
y_prob = nb.predict_proba(X_test)
plt.figure(figsize=(8, 6))
plt.hist(y_prob[:, 1], bins=10, color='blue', alpha=0.7)
plt.title('Predicted Probability Distribution for Class 1 (Lulus)')
plt.xlabel('Probability')
plt.ylabel('Frequency')
plt.show()

# Optionally: Save the Model
# import joblib
# joblib.dump(nb, 'naive_bayes_model.pkl')